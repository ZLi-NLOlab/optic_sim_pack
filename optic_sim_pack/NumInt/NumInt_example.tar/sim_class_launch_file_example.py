# """An example file that show how can one uses NumInt class. And also demonstrates how to modify 
# pre-defined behaviour of the class."""

# """In this example, we excite a soliton. Trap the soliton at tau = 5ps through 
# phase-modulation then move the locked soliton to tau = -5ps by moving the phase-modulation 
# position over N roundtrip"""

import optic_sim_pack as osp 
import numpy as np
import osp_param_file_generator

from matplotlib import rcParams, use
from optic_sim_pack.AuxFuncs.Load_save import raw_load

# """loading params, not necessary, one can define params directly"""
params = raw_load('sim_params.params')

# """define useful functions, namely, for initial E and E_in profile"""
def E_prof_func(t_sample, shift):
    phase = np.exp(-((t_sample - shift)/.5e-12)**2) * 2 * np.pi * .5  
    prof = np.ones(len(t_sample)) * np.exp(1j * phase)
    return prof

def E_prof(params_c):
    return E_prof_func(params_c.t_sample, params_c.t_shift)

def E_init_func(params_c):
    N = 1; P = 400
    tau = np.sqrt(N**2 * abs(params_c.betak[2])/params_c.gamma/P) 
    prof = 1/np.cosh(params_c.t_sample/tau) 
    return np.sqrt(P) * prof

# """various modifiable processing calls"""
init_position = 5e-12; final_position = -5e-12 
roundtrips = 3000 
interval = (final_position - init_position)/(roundtrips/ min(params['_S_intv'], params['_P_intv']))

# """as the integration manager initialise, we add t_shift to params_c for later use"""
def int_manager_init_call(self):
    self.params_c.t_shift = init_position
    self.plot_control.fig_vars.t_ylim = (-0.05, 5)
    self.status_c.data_save_list.insert(1, 't_shift') # add the 't_shift' as a variabel we want to save  

# """before the simulation is launched, we add the phase profile of the driving field a animated 
# object"""
def pre_launch_call(self):
    pass 
    ax = self.plot_control.fig_vars.twins[0]
    ax.cla()
    lt, = ax.plot(self.params_c.t_sample, np.unwrap(np.angle(self.params_c.E_in_prof)), c = 'C2', ls = '--')
    
    lt.set_animated(True)
    self.plot_control.fig_vars.animated_list.append((ax, lt))
    self.plot_control.canvas_update()

# """update y-data for phase-profile"""
def plotting_processing(self):
    self.plot_control.fig_vars.animated_list[-1][1].set_ydata(np.unwrap(np.angle(self.params_c.E_in_prof)))

# """once roundtrip is greater than 3000m, we want the phase-modulation shift toward tau = -5ps,
# also we only want to start saving after roundtrip reach 500 and stop the simulation at 8000 """
shift_start = 3000
def common_processing(self):
    if int(shift_start + roundtrips) >= self.params_c.rt_counter >= int(shift_start):
        self.params_c.E_in_prof = E_prof(self.params_c)
        self.params_c.t_shift += interval 

    if self.params_c.rt_counter == int(500):
        self.status_c.saving = True
        self.save_control.save_start()

    if self.params_c.rt_counter == int(8e3 + self.params_c._S_intv):
        raise StopIteration

# """initialise the NumInt_class"""
sim_class = osp.NumInt_class(
        params,                                                     # simulation params 
        E_in_prof = E_prof,                                         # driving field profile 
        E_init = E_init_func,                                       # initial E field 
        plotting = True, saving = False,                            # turn plot on while save off (save will be turned on later)
        save_name = 'example_sim',                                  # name of output files
        integration_method= 'LLE_ssf',                              # use LLE_ssf as integration mode 
        int_init_call  = int_manager_init_call,                     # additional initialisation call   
        pre_launch_call = pre_launch_call,                          # additional calls before simulation routine start
        plot_proc_call = plotting_processing,                       # additional plot processing every plotting call 
        common_proc_call = common_processing,                       # additional processing after plotting and saving calls
        status_c_attri = {'tar_final': True, 'tar_remove': True}    # add additional attribute to status_c
    )

# """launching the numerical integration routine"""
sim_class.launch()




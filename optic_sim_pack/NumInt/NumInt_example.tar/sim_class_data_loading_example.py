"""example load script"""

import numpy as np 
import matplotlib.pyplot as plt 
import optic_sim_pack as osp

from optic_sim_pack.AuxFuncs.Load_save import stack_load, tar_load_NumInt
from matplotlib import rcParams

rcParams['image.origin'] = 'lower'

data = tar_load_NumInt('example_sim.simout.tar.gz.83ab8a')

params = data['params']
E_data = data['data']

params_c = osp.NumInt_class(params, integration_method= type('empty', (), {})).params_c

t_sample = params_c.t_sample 
f_plot = params_c.f_plot
lam_grid = params_c.lam_grid

E_map = np.vstack([n[-1] for n in E_data])
t_shift = [n[1] for n in E_data]
rt = [n[0] for n in E_data]

fig = plt.figure(tight_layout = True)
ax1 = fig.add_subplot(111)

ax1.imshow(np.abs(E_map)**2, aspect = 'auto', extent = (t_sample[0], t_sample[-1], rt[0], rt[-1]))
ax1.plot(t_shift, rt, ls = '--', c = 'red', label = 'Phase-modulation peak')

ax1.set_xlabel('Fast time (s)')
ax1.set_ylabel('Roundtrip')

ax1.legend(loc = 1)
plt.show()

# """A typical file that generate simulation parameters file. This is not actually 
# necessary, one can define a dictionary of parameters and input directly to NumInt 
# class if one wishes. This is done solely for clarity"""

import numpy as np
from optic_sim_pack.AuxFuncs.Load_save import raw_save

c = 3e8
b3_zdw = 1.2949475e-40
b4_zdw = -6.659178e-55
b5_zdw = 0e-71
zdw = 1564.5221e-9
w_zdw = c/zdw * 2 * np.pi
tau1 = 12.2e-15 ; tau2 = 32e-15

def get_dispersion(w_p): 
    
    def b2(w_zdw, w_p, b3, b4, b5):
        b2_ = b3 * (w_p - w_zdw) + b4/2 * (w_p - w_zdw)**2 + b5/6 * (w_p - w_zdw)**3
        return b2_ 
    
    def b3(w_zdw, w_p, b3, b4, b5):
        b3_ = b3 + b4 * (w_p - w_zdw) + b5/2 * (w_p - w_zdw)**2
        return b3_
    
    def b4(w_zdw, w_p, b4, b5):
        b4 = b4 + b5*(w_p - w_zdw)
        return b4
    
    b2_ = b2(w_zdw, w_p, b3_zdw, b4_zdw, b5_zdw)
    b3_ = b3(w_zdw, w_p, b3_zdw, b4_zdw, b5_zdw)
    b4_ = b4(w_zdw, w_p, b4_zdw, b5_zdw)
    disp = {2: b2_, 3: b3_, 4: b4_}
    
    return disp

def param_create():

    params = dict()
    """cavity params"""
    params['finesse'] = 200                                     # cavity finesse 
    params['alpha'] = np.pi/params['finesse']               # half linear cavity loss coefficient
    params['gamma'] = 1.8e-3                                    # nonlinear coefficient 
    params['L'] = 1                                             # cavity length
    params['theta1'] =  0.01                                    # input coupling 
    params['fR'] = 0.18 * 0                                     # Raman fraction 
    params['RR_tau'] = (tau1, tau2)                             # Single-damped Raman time constants 
    params['RR_method'] = 'SigDamped'                           # Raman mode to be used  
    
    """driving params"""
    params['P_in'] = 30                                         # pump power 
    params['d'] =  12e-15                                        # pump pulse group-delay 
    params['del0'] = 30 * params['alpha']                        # detuning 
    params['order'] = 3                                         # orders of dispersion to be included 
    params['wl_pump'] = lam_c = 1600e-9                         # central wavelengt, actually optional
    params['betak'] = get_dispersion( c/lam_c * 2 * np.pi)      # dispersion coefficients
    params['p_in_dur'] = 1e-12                                  # pump duration: this is not actually used by sim_routine but passed for pump profile calc
 
    """sim params"""
    params['npt'] = 2**12       # number of grid points
    params['tspan'] = 30e-12    # temporal window  
    params['_M'] = 10e4         # max roundtrip  
    params['_N'] = 10           # step per roundtrip
    params['_S_intv'] = 5    # save interval  
    params['_P_intv'] = 10    # plot interval
    return params 

def params_save(params):
    raw_save(params, 'sim_params.params')
    print('param created')

# """The file will not do anything unless is called through import"""
if __name__ != '__main__':
    params = param_create()
    params_save(params)

